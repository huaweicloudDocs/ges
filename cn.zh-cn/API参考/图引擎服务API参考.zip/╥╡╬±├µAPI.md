# 业务面API<a name="ges_03_0047"></a>

-   **[业务面API使用方法](业务面API使用方法.md)**  

-   **[环境准备](环境准备-0.md)**  

-   **[业务面API概览](业务面API概览.md)**  

-   **[点操作API](点操作API.md)**  

-   **[边操作API](边操作API.md)**  

-   **[元数据操作API](元数据操作API.md)**  

-   **[Gremlin操作API](Gremlin操作API.md)**  

-   **[算法API](算法API.md)**  

-   **[路径API](路径API.md)**  

-   **[图统计API](图统计API.md)**  

-   **[Job管理API](Job管理API.md)**  

-   **[错误码](错误码-4.md)**  


