# Gremlin操作API<a name="ges_03_0117"></a>

-   **[执行Gremlin查询\(1.0.0\)](执行Gremlin查询(1-0-0).md)**  


