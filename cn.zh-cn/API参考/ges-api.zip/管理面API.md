# 管理面API<a name="ges_03_0048"></a>

-   **[系统管理API](系统管理API.md)**  

-   **[图管理API](图管理API.md)**  

-   **[备份管理API](备份管理API.md)**  

-   **[元数据管理API](元数据管理API.md)**  

-   **[任务中心API](任务中心API.md)**  


