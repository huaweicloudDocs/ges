# API概览<a name="ges_03_0134"></a>

-   **[管理面API概览](管理面API概览.md)**  

-   **[业务面API概览](业务面API概览.md)**  


