# OBS对象名约束<a name="ZH-CN_TOPIC_0262771530"></a>

图引擎服务支持的OBS对象名支持以下字符：

<a name="table2049845215212"></a>
<table><tbody><tr id="row12534145218216"><td class="cellrowborder" valign="top" width="25.729999999999997%"><p id="p45341252112113"><a name="p45341252112113"></a><a name="p45341252112113"></a>字母数字字符</p>
</td>
<td class="cellrowborder" valign="top" width="74.27%"><p id="p15534135213212"><a name="p15534135213212"></a><a name="p15534135213212"></a>0-9 a-z A-Z</p>
</td>
</tr>
<tr id="row1153413525213"><td class="cellrowborder" valign="top" width="25.729999999999997%"><p id="p9534135272118"><a name="p9534135272118"></a><a name="p9534135272118"></a>特殊字符</p>
</td>
<td class="cellrowborder" valign="top" width="74.27%"><p id="p17534195212216"><a name="p17534195212216"></a><a name="p17534195212216"></a>! - _ . * ' ( )</p>
</td>
</tr>
</tbody>
</table>

>![](public_sys-resources/icon-note.gif) **说明：** 
>暂不支持的字符有：\\ \{ ^ \} % \` \] " \> \[ \~ < \# |  & @ : , $ = + ? ; 空格 ASCII控制字符（字符范围00–1F十六进制（0–31十进制）和 7F（127十进制））

