# 业务面API<a name="ges_03_0047"></a>

-   **[点操作API](点操作API.md)**  

-   **[边操作API](边操作API.md)**  

-   **[元数据操作API](元数据操作API.md)**  

-   **[Gremlin操作API](Gremlin操作API.md)**  

-   **[算法API](算法API.md)**  

-   **[路径API](路径API.md)**  

-   **[图统计API](图统计API.md)**  

-   **[子图操作API](子图操作API.md)**  

-   **[Job管理API](Job管理API.md)**  


